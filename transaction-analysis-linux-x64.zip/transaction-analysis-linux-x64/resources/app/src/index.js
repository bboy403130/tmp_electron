import React from 'react';
import ReactDOM from 'react-dom';
import Analysis from './components/Analysis';

window.onload = function() {
	ReactDOM.render(<Analysis />, document.getElementById('app'));
};
