import React from 'react';

export default class Quantity extends React.Component {
	constructor() {
		super();
	}

	render() {
		return (
			<div>
			tmeplate
			</div>
		);
	}
}
const styles = {
	
};

